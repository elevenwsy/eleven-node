- 执行 pip3 install django  安装Django



- 执行 ./runserver.sh 启动服务

  由于需要80端口权限，是sudo方式启动，需要输入当前用户密码